

def is_integer(arg):
    pass


def is_numberic(arg):
    pass


def numberic_helper_1(arg):
    pass


def numberic_helper_2(arg):
    pass

