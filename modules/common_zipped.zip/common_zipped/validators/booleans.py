
def is_boolean(arg):
    pass


def boolean_helper_1(arg):
    pass


def boolean_helper_2(arg):
    pass
